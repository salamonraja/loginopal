<?php
//Salt is a random set of letters and numbers used to obfuscatce a password as a porotection against rainbow lists. 
$salt = 'sWiafoAxoeGoa5ia';

// Information needed to connect to the MySQL database
$database['host'] = 'localhost';
$database['user'] = '';
$database['pass'] = '';
$database['database'] = '';
