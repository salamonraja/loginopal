php-demo-1
==========

A script to demonstrate how to manipulate data from a form and store it in a database. And then to access the data and work with it.